public class Divide{
    public static int div(int[] arr){
        return arr[0] / arr[2];
    }
}